let selectedService = {};

function selectService(type, qty, coins) {
  selectedService = { type, qty, coins };
  document.getElementById('modalServiceTitle').textContent = 
    `Pedir ${qty} ${type === 'followers' ? 'Seguidores' : type === 'likes' ? 'Curtidas' : type}`;
  document.getElementById('orderModal').style.display = 'flex';
}

function closeModal() {
  document.getElementById('orderModal').style.display = 'none';
}

async function proceedToOrder() {
  const link = document.getElementById('fbLink').value.trim();
  if (!link) return alert("Por favor, insira o link do Facebook!");

  localStorage.setItem('pendingOrder', JSON.stringify({
    ...selectedService,
    link
  }));

  const { data: { session } } = await supabase.auth.getSession();
  if (session) {
    window.location.href = 'order.html';
  } else {
    window.location.href = 'auth/register.html';
  }
}

function goToLogin() {
  window.location.href = 'auth/login.html';
}

function startOrder() {
  selectService('followers', 50, 100);
}