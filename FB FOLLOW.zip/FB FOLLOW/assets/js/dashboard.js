async function loadDashboard() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return window.location.href = '../../auth/login.html';

  // Nome do usuário
  const { data: profile } = await supabase.from('profiles').select('full_name').eq('id', user.id).single();
  document.getElementById('userName').textContent = profile?.full_name?.split(' ')[0] || 'Amigo';

  // Saldo de coins
  const { data: balance } = await supabase.from('coins_balance').select('balance').eq('user_id', user.id).single();
  document.getElementById('coinBalance').textContent = `${balance?.balance || 0} coins`;
}

async function confirmOrder() {
  const orderData = JSON.parse(localStorage.getItem('pendingOrder'));
  const { data: { user } } = await supabase.auth.getUser();

  const { error } = await supabase.from('orders').insert({
    user_id: user.id,
    service_type: orderData.type,
    quantity: orderData.qty,
    target_link: orderData.link,
    coins_spent: orderData.coins
  });

  if (!error) {
    alert("✅ Pedido realizado com sucesso! Estamos processando.");
    localStorage.removeItem('pendingOrder');
    window.location.href = 'dashboard/index.html';
  }
}

async function logout() {
  await supabase.auth.signOut();
  window.location.href = '../../index.html';
}

// Carregar dashboard automaticamente
if (window.location.pathname.includes('dashboard')) {
  loadDashboard();
}