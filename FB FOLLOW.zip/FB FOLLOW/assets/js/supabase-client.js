const supabaseUrl = 'https://SEU-PROJETO.supabase.co';
const supabaseAnonKey = 'SUA_ANON_KEY_AQUI';

const supabase = Supabase.createClient(supabaseUrl, supabaseAnonKey);

async function checkAuth() {
  const { data: { session } } = await supabase.auth.getSession();
  if (session) {
    document.getElementById('dash-link').style.display = 'inline';
  }
}

checkAuth();